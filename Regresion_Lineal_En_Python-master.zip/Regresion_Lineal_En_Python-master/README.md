# Programación de la Regresión Lineal en Python

Set de datos y código fuente donde se implementa la Regresión Lineal en Python sin usar librerías de *Machine Learning*, como se muestra en [este video](https://youtu.be/rjeCBUMrj8A)

Para la explicación paso a paso visita el [artículo en Codificando Bits](https://codificandobits.com/deep-learning/2018/07/23/programacion-de-la-regresion-lineal-en-python.html).
